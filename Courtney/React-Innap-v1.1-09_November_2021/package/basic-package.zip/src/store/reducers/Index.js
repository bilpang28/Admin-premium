import todoReducers from './Reducers';
import {combineReducers} from 'redux';

const rootReducers = combineReducers({
	todoReducers
})

export default rootReducers;