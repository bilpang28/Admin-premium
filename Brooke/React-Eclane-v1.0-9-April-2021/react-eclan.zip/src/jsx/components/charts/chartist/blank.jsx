import React, { Component } from 'react';



function Blank() {

    return (
        <>
            
        </>
    )
}

export default Blank;