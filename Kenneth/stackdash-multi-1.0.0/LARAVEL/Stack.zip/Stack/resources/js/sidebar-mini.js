import 'stack/src/js/sidebar-mini'

(function(){
  'use strict';

  // ENABLE sidebar menu tabs
  $('#sidebar-mini-tabs [data-toggle="tab"]').on('click', function (e) {
    e.preventDefault()
    $(this).tab('show')
  })
})()