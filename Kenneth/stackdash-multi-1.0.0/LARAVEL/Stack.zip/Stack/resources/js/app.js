require('./bootstrap');

require('stack/src/js/app')