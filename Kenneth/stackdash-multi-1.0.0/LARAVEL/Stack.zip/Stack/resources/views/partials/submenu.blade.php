<div class="navbar navbar-secondary navbar-light navbar-expand-sm p-0">
  <button class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#navbarsExample03" type="button">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="navbar-collapse collapse" id="navbarsExample03">
    @include('stack::partials.navbar-menu')
  </div>
</div>