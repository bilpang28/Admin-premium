<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="ltr">
<head>
    @include('stack::partials.header')
</head>

@php
    $layout = 'default';
@endphp

<body class="{{ $bodyClass ?? 'layout-fluid' }}">

  @include('stack::partials.preloader')
  
  @yield('content')

  @include('stack::partials.footer')
  @yield('footer')
</body>
</html>