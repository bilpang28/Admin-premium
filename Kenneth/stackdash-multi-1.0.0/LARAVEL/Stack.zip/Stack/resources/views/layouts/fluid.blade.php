<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="ltr">
<head>
    @include('stack::partials.header')
</head>

@php
    $layout = 'fluid';
    $navbarContainerClass = $navbarContainerClass ?? 'container-fluid';
    $drawerAlign = 'end';
    $dashboards_menu = request()->routeIs(['home', 'quick-access', 'staff', 'ecommerce']);
    $apps_menu = request()->routeIs(['app-trello', 'app-projects', 'app-activities', 'app-fullcalendar', 'app-chat', 'app-email', 'app-course', 'app-lesson']);
    $pages_menu = request()->routeIs(['companies', 'stories', 'discussions', 'tickets', 'payout', 'invoice', 'pricing', 'edit-account', 'blank', 'profile', 'digital-product', 'login', 'register']);
    $components_menu = request()->routeIs(['ui-buttons', 'ui-alerts', 'ui-avatars', 'ui-modals', 'ui-charts', 'ui-icons', 'ui-forms', 'ui-range-sliders', 'ui-datetime', 'ui-tables', 'ui-tabs', 'ui-loaders', 'ui-drag', 'ui-pagination', 'ui-vector-maps']);
@endphp

<body class="layout-fluid layout-sticky-subnav {{ $bodyClass ?? '' }}">

    @include('stack::partials.preloader')

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->
        <div id="header" class="mdk-header js-mdk-header {{ $headerClass ?? 'mb-0' }}" data-fixed>
            <div class="mdk-header__content">
                @include('stack::partials.navbar')
            </div>
        </div>
        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content page {{ $pageContentClass ?? '' }}">

            @auth
                @if($user_header ?? true !== false)
                    @include('stack::partials.user-header')
                @endif
            @endauth

            @if($submenu ?? true !== false)
                <div class="page__header page__header-nav">
                    <div class="{{ $containerClass }} page__container">
                        @include('stack::partials.submenu')
                    </div>
                </div>
            @endif

            @yield('content')
        </div>
        <!-- // END Header Layout Content -->

    </div>
    <!-- // END Header Layout -->

    @include('stack::partials.drawer')
    {{-- @include('stack::partials.app-settings') --}}

    @include('stack::partials.footer')
    @yield('footer')
</body>
</html>
