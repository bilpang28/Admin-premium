const mix     = require('laravel-mix')
const glob    = require('glob')
const argv    = require('yargs').argv
const del     = require('del')
const merge   = require('webpack-merge').smart
let webpackConfig = {}

///////////////////
// Configuration //
///////////////////

const MergeConfig = require('merge-config')
let config = new MergeConfig()

config.merge({
  runTasks: {
    clean: true,
    js: true,
    copy: true,
    sass: true,
    html: true,
    browserSync: true
  },
  enableCssThemes: false,
  // create additional .rtl.css
  enableCssRTL: false,
  // expose globals
  expose: [],
  // copy assets list i.e. 
  // copyCwd: 'node_modules'
  // copyDest: 'dist/assets/vendor'
  // copy: ['bootstrap/dist/bootstrap.js']
  // => will copy node_modules/bootstrap/dist/bootstrap.js to dist/assets/vendor/bootstrap.js
  copyCwd: 'node_modules',
  copyDest: 'dist/assets/vendor',
  copy: [],
  clean: [
    'dist/**/*.html',
    'dist/assets/{css,fonts,js,vendor}',
  ],
  sassSrc: 'src/sass/*.scss',
  cssDest: 'dist/assets/css',
  jsSrc: 'src/js/**/**.{js,vue}',
  jsDest: 'dist/assets/js',
  htmlSearchPaths: [
    './src/html'
  ],
  htmlDest: 'dist/[path][name].html',
  htmllint: true,
  aliasRoot: Mix.sees('laravel') 
    ? path.join('resources', 'js') 
    : 'src',
  // options passed to laravel-mix
  laravelMixOptions: {
    // ignore fonts
    processCssUrls: false,
  },
  browserSync: require('theme-mix/bs-config.json'),
})

////////////////////////
// User configuration //
////////////////////////

try {
  config.file(path.join(process.cwd(), 'theme-mix.yaml'))
}
catch (e) {
  if (e.message.indexOf('ENOENT') === -1) {
    console.error(e.message)
    process.exit()
  }
}

///////////////////////////////////////////
// RUN SPECIFIC TASKS                    //
// npm run development -- --env.run html //
// npm run development -- --env.run js   //
// npm run development -- --env.run sass //
// npm run development -- --env.run copy //
///////////////////////////////////////////

const __RUN = argv.env ? argv.env.run : undefined

// npm run development -- --env.theme dark
const __THEME = argv.env ? argv.env.theme || 'default' : 'default'

let JavaScript  = require('laravel-mix/src/components/JavaScript')
let Vue         = require('laravel-mix/src/components/Vue')
let BrowserSync = require('laravel-mix/src/components/Browsersync')
let Copy        = require('laravel-mix/src/components/Copy')
let Sass        = require('laravel-mix/src/components/Sass')
let Css         = require('laravel-mix/src/components/Css')

class ThemeMix {
  constructor() {
    this.javaScript     = new JavaScript()
    this.browserSync    = new BrowserSync()
    this.copy           = new Copy()
    this.vue            = new Vue()
    this.sass           = new Sass()
    this.css            = new Css()
    this.config         = config
  }

  get runBrowserSync() {
    return !__RUN && !Mix.isUsing('hmr') && this.config.get('runTasks:browserSync')
  }

  get runSass() {
    return __RUN === 'sass' || (!__RUN && this.config.get('runTasks:sass'))
  }

  get runCopy() {
    return __RUN === 'copy' || (!__RUN && this.config.get('runTasks:copy'))
  }

  get runJavaScript() {
    return __RUN === 'js' || (!__RUN && this.config.get('runTasks:js'))
  }

  get runClean() {
    return __RUN === 'clean' || (!__RUN && this.config.get('runTasks:clean'))
  }

  register(options = {}) {
    this.config.merge(options)

    // Enable sourcemaps
    const sourceMapsInProduction = false
    mix.sourceMaps(sourceMapsInProduction)

    // https://github.com/JeffreyWay/laravel-mix/issues/1793
    if (!mix.inProduction()) {
      mix.webpackConfig({
        devtool: 'inline-source-map'
      })
    }

    mix.options(this.config.get('laravelMixOptions'))

    mix.webpackConfig({
      resolve: {
        alias: {
          '~': path.join(__dirname, this.config.get('aliasRoot'))
        }
      }
    })

    if (Mix.isUsing('hmr')) {
      mix.setResourceRoot(`//${Config.hmrOptions.port}:${Config.hmrOptions.port}/`);
    }

    if (mix.inProduction()) {
      mix.webpackConfig({
        module: {
          rules: [{
            test: /\.jsx?$/,
            exclude: /(node_modules\/(core-js|@babel\b)|bower_components)/,
            use: [
              {
                loader: 'babel-loader',
                options: Config.babel()
              }
            ]
          }]
        }
      })
    }
  }

  boot() {

    // cleanup
    del.sync('temp/')

    this.cleanTask()
      .javaScriptTask()
      .copyTask()
      .sassTask()

    /////////
    // RTL //
    /////////

    if (this.runSass && this.config.get('enableCssRTL')) {
      const WebpackRTLPlugin = require('webpack-rtl-plugin')
      const WebpackRTLWrapPlugin = require('webpack-rtl-wrap-plugin')
      const cacheDirectory = path.resolve(path.join('temp', 'rtl', __THEME))

      del.sync(cacheDirectory)

      webpackConfig = merge(webpackConfig, { 
        plugins: [
          // Creates .rtl.css
          new WebpackRTLPlugin({
            minify: false
          }),
          // wraps CSS into [dir=ltr|rtl]
          new WebpackRTLWrapPlugin({
            cacheDirectory
          })
        ]
      })
    }

    /////////////////
    // BROWSERSYNC //
    /////////////////

    if (this.runBrowserSync) {
      this.browserSync.register(this.config.get('browserSync'))
    }
  }

  /**
   * Clean
   * npm run development -- --env.run clean
   * @return {ThemeMix}
   */
  cleanTask() {
    if (this.runClean) {
      del.sync(this.config.get('clean'))
    }
    return this
  }

  /**
   * Clean
   * npm run development -- --env.run js
   * @return {ThemeMix}
   */
  javaScriptTask() {
    if (this.runJavaScript) {
      const files = glob.sync(this.config.get('jsSrc'), { ignore: '**/_*' })
        .filter(file => !Mix.isUsing('hmr') ? file.indexOf('hmr') === -1 : true)

      for (let file of files) {
        this.javaScript.register(file, this.config.get('jsDest'))
      }
    }
    return this
  }

  /**
   * COPY VENDOR ASSETS from node_modules
   * npm run development -- --env.run copy
   * @return {ThemeKit}
   */
  copyTask() {
    if (this.runCopy) {
      this.config.get('copy').forEach(asset => {
        var dest = path.join(process.cwd(), this.config.get('copyDest'))
        var src = asset
        if (asset instanceof Object) {
          src = Object.keys(asset).pop()
          dest = Object.values(asset).pop()
        }
        for (let file of glob.sync(src, { cwd: path.join(process.cwd(), this.config.get('copyCwd')) })) {
          this.copy.register(path.join(process.cwd(), this.config.get('copyCwd'), file), dest)
        }
      })
    }
    return this
  }

  /**
   * Sass
   * npm run development -- --env.run sass
   * @return {ThemeKit}
   */
  sassTask() {
    if (this.runSass) {
      let __DIST_CSS = this.config.get('cssDest')

      let sassOptions = {
        // Add node_modules to includePaths
        includePaths: ['node_modules']
      }

      if (this.config.get('enableCssThemes')) {
        // inject $theme variable
        sassOptions.data = '$theme: ' + __THEME + ';'
        __DIST_CSS += '/themes/' + __THEME
      }

      for (let file of glob.sync(this.config.get('sassSrc'), { ignore: '**/_*' })) {
        this.sass.register(file, __DIST_CSS, sassOptions)
      }
    }

    return this
  }

  webpackConfig(webpackConfig) {
    if (this.runJavaScript) {
      this.javaScript.webpackConfig(webpackConfig)
    }
    if (this.runSass) {
      ;['scss', 'sass'].map(loader => this.deleteRule(loader, webpackConfig.module.rules))
    }
    if (this.runJavaScript || this.runSass) {
      this.addSassIncludePaths(webpackConfig)
    }
  }

  webpackRules() {
    let rules = []
    if (this.runJavaScript) {
      rules = rules.concat(this.javaScript.webpackRules())
    }
    if (this.runSass) {
      rules = rules.concat(this.sass.webpackRules())
        .concat(this.css.webpackRules())

      let updateCssExclude = (rule) => rule.exclude = this.excludePathsFor('sass')

      this.updateRule('scss', rules, updateCssExclude)
      this.updateRule('sass', rules, updateCssExclude)
    }
    return rules
  }

  webpackPlugins() {
    let plugins = []
    if (this.runSass) {
      plugins = plugins.concat(this.sass.webpackPlugins())
    }
    if (this.runBrowserSync) {
      plugins = plugins.concat(this.browserSync.webpackPlugins())
    }
    return plugins
  }

  webpackEntry(entry) {
    if (this.runJavaScript) {
      this.javaScript.webpackEntry(entry)
    }
    if (this.runSass) {
      this.sass.webpackEntry(entry)
    }
  }

  dependencies() {
    const dependencies = (this.javaScript.dependencies() || [])
      .concat((this.sass.dependencies() || []))
      .concat((this.browserSync.dependencies() || []))

    return dependencies
  }

  addSassIncludePaths(webpackConfig) {
    let sassCallback = rule => {
      if (Mix.seesNpmPackage('sass')) {
        rule.loaders.find(
          loader => loader.loader === 'sass-loader'
        ).options.includePaths = ['node_modules', 'src/sass'];
      }
    }

    this.vue.updateCssLoader('scss', webpackConfig, sassCallback)
    this.vue.updateCssLoader('sass', webpackConfig, sassCallback)
  }

  excludePathsFor(preprocessor) {
    let exclusions = this[preprocessor]

    return exclusions
      ? exclusions.details.map(preprocessor => preprocessor.src.path())
      : []
  }

  findRule(loader, rules) {
    return rules.find(rule => {
      return rule.test instanceof RegExp && rule.test.test('.' + loader);
    })
  }

  findRuleIndex(loader, rules) {
    return rules.findIndex(rule => {
      return rule.test instanceof RegExp && rule.test.test('.' + loader);
    })
  }

  updateRule(loader, rules, callback) {
    let rule = this.findRule(loader, rules)
    callback && callback(rule, rules, loader)
  }

  deleteRule(loader, rules) {
    this.updateRule(loader, rules, (rule, rules, loader) => {
      let index = this.findRuleIndex(loader, rules)
      rules.splice(index, 1)
    })
  }
}

//////////////
// NUNJUCKS //
//////////////

// npm run development -- --env.run html
if (__RUN === 'html' || (!__RUN && config.get('runTasks:html'))) {
  let Entry = require('laravel-mix/src/builder/Entry')
  let entry = new Entry()

  for (let file of glob.sync('src/html/pages/*.html', { ignore: '**/_*' })) {
    entry.add('mix', path.resolve(file))
  }

  let loaders = [{
    loader: 'file-loader',
    options: {
      name: config.get('htmlDest'),
      context: './src/html/pages',
      useRelativePath: false
    }
  }]

  if (config.get('htmllint')) {
    loaders.push({
      loader: 'html-validate-loader'
    })
  }

  loaders = loaders.concat(['jsbeautify-loader', {
    loader: 'nunjucks-html-loader',
    options: {
      searchPaths: config.get('htmlSearchPaths')
    }
  }, 'front-matter-loader'])

  webpackConfig = merge(webpackConfig, {
    entry: entry.get(),
    resolveLoader: {
      alias: {
        'html-validate-loader': path.join(__dirname, './htmllint/webpack-html-validate-loader.js'),
      }
    },
    module: {
      rules: [{
        test: /\.html$/,
        loaders
      }]
    }
  })
}

////////////////////
// EXPOSE GLOBALS //
////////////////////

if (config.get('expose')) {
  const exposeConfig = {
    module: {
      rules: []
    }
  }

  config.get('expose').forEach(expose => {
    const library = Object.keys(expose)[0]
    const globals = typeof expose[library] === 'string' 
      ? [expose[library]] 
      : expose[library]

    const rule = {
      test: require.resolve(library),
      use: []
    }
    globals.forEach(name => rule.use.push({ loader: 'expose-loader', options: name }))
    exposeConfig.module.rules.push(rule)
  })

  webpackConfig = merge(webpackConfig, exposeConfig)
}

//////////////////
// APPLY CONFIG //
//////////////////

if (Config.webpackConfig) {
  webpackConfig = merge(Config.webpackConfig, webpackConfig)
}

mix.webpackConfig(webpackConfig)

let themeMix = new ThemeMix()

mix.extend('themeMix', themeMix)

module.exports = {
  config,
  mix
}