<?php 

namespace App\Stack;

class Stack
{
    use AuthorizesRequests;
}
