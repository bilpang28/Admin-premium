<?php

return [
    'brand' => 'Stack',
    'domain' => null,
    'path' => null
];
