<?php

namespace App\Stack\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Stack\Http\Middleware\SetDefaultLayoutForUrls;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', SetDefaultLayoutForUrls::class]);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('stack::home');
    }

    /**
     * Show analytics dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function quickAccess()
    {
        return view('stack::quick-access');
    }

    /**
     * Show staff.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function staff()
    {
        return view('stack::staff');
    }

    /**
     * Show shop dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function ecommerce()
    {
        return view('stack::ecommerce');
    }

    /**
     * Show trello.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appTrello()
    {
        return view('stack::app-trello');
    }

    /**
     * Show projects.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appProjects()
    {
        return view('stack::app-projects');
    }

    /**
     * Show activities.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appActivities()
    {
        return view('stack::app-activities');
    }

    /**
     * Show full calendar.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appFullcalendar()
    {
        return view('stack::app-fullcalendar');
    }

    /**
     * Show chat.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appChat()
    {
        return view('stack::app-chat');
    }

    /**
     * Show email.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appEmail()
    {
        return view('stack::app-email');
    }

    /**
     * Show course.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appCourse()
    {
        return view('stack::app-course');
    }

    /**
     * Show lesson.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function appLesson()
    {
        return view('stack::app-lesson');
    }

    /**
     * Show companies.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function companies()
    {
        return view('stack::companies');
    }

    /**
     * Show stories.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function stories()
    {
        return view('stack::stories');
    }

    /**
     * Show discussions.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function discussions()
    {
        return view('stack::discussions');
    }

    /**
     * Show tickets.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function tickets()
    {
        return view('stack::tickets');
    }

    /**
     * Show payout.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function payout()
    {
        return view('stack::payout');
    }

    /**
     * Show invoice.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function invoice()
    {
        return view('stack::invoice');
    }

    /**
     * Show digital product.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function digitalProduct()
    {
        return view('stack::digital-product');
    }

    /**
     * Show edit account.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function editAccount()
    {
        return view('stack::edit-account');
    }

    /**
     * Show profile.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function profile()
    {
        return view('stack::profile');
    }
}
