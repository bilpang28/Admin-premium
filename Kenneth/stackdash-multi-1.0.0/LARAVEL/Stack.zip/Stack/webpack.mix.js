let { mix } = require('./ThemeMix')
require('laravel-mix-merge-manifest')

mix.themeMix({
  runTasks: {
    clean: false,
    js: true,
    copy: true,
    sass: true,
    html: false,
    browserSync: true
  }
})

mix.options({
  hmrOptions: {
    host: 'stack-laravel.test',
    port: 8080
  }
})

mix
  .extract()
  .version()
  .mergeManifest()
