<?php

namespace App\Stack;

use App\Stack\Http\Middleware\Authorize;
use App\Stack\Http\Middleware\SetDefaultLayoutForUrls;
use App\Stack\Stack;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class StackServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->authorization();

        Route::middlewareGroup('stack', config('stack.middleware', [
            'web',
            Authorize::class,
            SetDefaultLayoutForUrls::class,
        ]));

        $this->registerRoutes();

        $this->loadViewsFrom(
            __DIR__.'/resources/views', 'stack'
        );

        $this->setViewsGlobals();

        $this->publishes([
            __DIR__.'/theme-mix.yaml' => base_path('theme-mix.yaml'),
            __DIR__.'/ThemeMix.js' => base_path('ThemeMix.js'),
            __DIR__.'/webpack.mix.js' => base_path('webpack.mix.js'),
        ], 'mix');

        $this->publishes([
            __DIR__.'/config.php' => config_path('stack.php'),
        ], 'config');

        $this->publishes([
            __DIR__.'/resources/views' => resource_path('views/vendor/stack'),
        ], 'views');

        $this->publishes([
            __DIR__.'/resources/js' => resource_path('js'),
            __DIR__.'/resources/sass' => resource_path('sass'),
        ], 'assets');
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->mergeConfigFrom(
            __DIR__.'/config.php', 'stack'
        );
    }

    /**
     * Configure the Stack authorization services.
     *
     * @return void
     */
    protected function authorization()
    {
        $this->gate();

        stack::auth(function ($request) {
            return app()->environment('local') ||
                   Gate::check('viewStack', [$request->user()]);
        });
    }

    /**
     * Register the Stack gate.
     *
     * This gate determines who can access Stack in non-local environments.
     *
     * @return void
     */
    protected function gate()
    {
        Gate::define('viewStack', function ($user) {
            return in_array($user->email, [
                // 
            ]);
        });
    }

    /**
     * Get the Stack route group configuration array.
     *
     * @return array
     */
    private function routeConfiguration()
    {
        return [
            'domain' => config('stack.domain'),
            'namespace' => 'App\Stack\Http\Controllers',
            'prefix' => config('stack.path', 'stack'),
            'middleware' => 'stack',
        ];
    }

    /**
     * Register the package routes.
     *
     * @return void
     */
    private function registerRoutes()
    {
        Route::group($this->routeConfiguration(), function () {
            $this->loadRoutesFrom(__DIR__.'/Http/routes.php');
            $this->authRoutes();
        });
    }

    /**
     * Register the typical authentication routes for an application.
     *
     * @param  array  $options
     * @return void
     */
    public function authRoutes(array $options = [])
    {
        // Authentication Routes...
        Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
        Route::post('login', 'Auth\LoginController@login');
        Route::post('logout', 'Auth\LoginController@logout')->name('logout');

        // Registration Routes...
        if ($options['register'] ?? true) {
            Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
            Route::post('register', 'Auth\RegisterController@register');
        }

        // Password Reset Routes...
        if ($options['reset'] ?? true) {
            $this->resetPassword();
        }

        // Password Confirmation Routes...
        if ($options['confirm'] ?? true) {
            $this->confirmPassword();
        }

        // Email Verification Routes...
        if ($options['verify'] ?? false) {
            $this->emailVerification();
        }
    }

    /**
     * Register the typical reset password routes for an application.
     *
     * @return void
     */
    public function resetPassword()
    {
        Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
        Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
        Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
        Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('password.update');
    }

    /**
     * Register the typical confirm password routes for an application.
     *
     * @return void
     */
    public function confirmPassword()
    {
        Route::get('password/confirm', 'Auth\ConfirmPasswordController@showConfirmForm')->name('password.confirm');
        Route::post('password/confirm', 'Auth\ConfirmPasswordController@confirm');
    }

    /**
     * Register the typical email verification routes for an application.
     *
     * @return void
     */
    public function emailVerification()
    {
        Route::get('email/verify', 'Auth\VerificationController@show')->name('verification.notice');
        Route::get('email/verify/{id}/{hash}', 'Auth\VerificationController@verify')->name('verification.verify');
        Route::post('email/resend', 'Auth\VerificationController@resend')->name('verification.resend');
    }

    private function setViewsGlobals()
    {
        View::composer('*', function($view) {
            $layout = session('layout');
            $containerClass = 'container-fluid page__container';
            
            if ($layout === 'fixed' || $layout === 'mini') {
                $containerClass = 'container page__container';
            }

            $view->with(compact('layout', 'containerClass'));
        });
    }
}
